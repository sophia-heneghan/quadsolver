from setuptools import setup

setup(
    name='quadsolver',
    version='0.1.0',
    packages=['quadsolver'],
    url='',
    license='',
    author='sophia',
    author_email='',
    description=''
)
